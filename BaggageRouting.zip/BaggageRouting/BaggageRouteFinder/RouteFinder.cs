﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaggageRouteFinder
{
    public class RouteFinder: IRouting
    {
        #region Variable Declarations
        private List<DepartureDetail> _Departures;
        private List<BagDetail> _Bags;
        private List<NodeDetail> _NodeDetails;
        private List<DestNodes> _tempDestNodes;
        private string currentEntryNode;
        private string initialNode;
        private string FinalDestNode;
        private List<ProcessingRoutes> _processingNodes;
        private char[] whiteSpaceDelimiter = new char[] { ' ', '\t' };
        private const string SECTIONONEHEADER = "# Section: Conveyor System";
        private const string SECTIONTWOHEADER = "# Section: Departures";
        private const string SECTIONTHREEHEADER = "# Section: Bags";
        private const string ARRIVALFLIGHTID = "ARRIVAL";
        private const string TERMINATIONGATE = "BaggageClaim";
        #endregion

        public RouteFinder()
        {
            ResetData();
        }

        private void ResetData()
        {
            _Departures = new List<DepartureDetail>();
            _Bags = new List<BagDetail>();
            _NodeDetails = new List<NodeDetail>();
        }

        
        #region Function for Validating the format of input Data
        public bool validateInputDataFormat(string[] inputStr)
        {
            ResetData();
            int currentsection = 0;
            int stringNotinFormat = 0;
            foreach (string line in inputStr)
            {
                if (line.ToString().Trim() == SECTIONONEHEADER)
                {
                    currentsection = 1;
                    continue;
                }
                else if (line.ToString().Trim() == SECTIONTWOHEADER)
                {
                    currentsection = 2;
                    continue;
                }
                else if (line.ToString().Trim() == SECTIONTHREEHEADER)
                {
                    currentsection = 3;
                    continue;
                }
                if (line.ToString().Trim() != "")
                {
                    if (currentsection == 1)
                    {
                        string[] _csSectionDetail = line.Split(whiteSpaceDelimiter);
                        int _traveltime = 0;
                        if (_csSectionDetail.Length != 3)
                            stringNotinFormat = -1;
                        else if (int.TryParse(_csSectionDetail[2], out _traveltime) == false)
                            stringNotinFormat = -1;
                        else
                            AddNodeDetails(_csSectionDetail[0], _csSectionDetail[1], _traveltime);
                    }
                    else if (currentsection == 2)
                    {
                        string[] _DepartureSectionDetail = line.Split(whiteSpaceDelimiter);
                        TimeSpan _Deptarturetime;
                        if (_DepartureSectionDetail.Length != 4)
                            stringNotinFormat = -1;
                        else if (TimeSpan.TryParse(_DepartureSectionDetail[3], out _Deptarturetime) == false)
                            stringNotinFormat = -1;
                        else
                            AddDepartures(_DepartureSectionDetail[0], _DepartureSectionDetail[1], _DepartureSectionDetail[2], _Deptarturetime);
                    }
                    else if (currentsection == 3)
                    {
                        string[] _BagSectionDetail = line.Split(whiteSpaceDelimiter);
                        if (_BagSectionDetail.Length != 3)
                            stringNotinFormat = -1;
                        else
                            AddBagsDetails(_BagSectionDetail[0], _BagSectionDetail[1], _BagSectionDetail[2]);
                    }
                }
                else if (currentsection == 0)
                    break;


                if (stringNotinFormat == -1)
                    break;
            }
            // some sections are missing
            if (currentsection <3)
                return false;
            // section details are not in correct format
            if (stringNotinFormat == -1)
                return false;


            return true;
        }
        #endregion

        #region Route Generator functions
        public string[] GenerateRoute()
        {
            string[] outputstr = new string[_Bags.Count];
            int bgIndex = 0;
            foreach (BagDetail bg in _Bags)
            {
                string OutputVal = GetRoutes(bg.EntryPointGate, (bg.DestflightId.ToUpper().Trim() == ARRIVALFLIGHTID ? TERMINATIONGATE : GetDestinationGate(bg.DestflightId)));
                outputstr[bgIndex] = bg.bagNumber + " " + OutputVal;
                bgIndex++;
            }
            return outputstr;
        }

        private string GetRoutes(string EntryNode, string DestNode)
        {
            FinalDestNode = DestNode;
            initialNode = EntryNode;
            _processingNodes = new List<ProcessingRoutes>();
           
            AddUnVisitedNodes(initialNode,0,"",0,false);
             
            while ((_processingNodes.Where(a => a.visited == false).Count() != 0))
            {
                ProcessingRoutes _psCurrent = _processingNodes.Where(a => a.visited == false).First();
                currentEntryNode = _psCurrent.Node;
                string previousCoveredNodes = _psCurrent.enroute;
                int previousTravelTimes = _psCurrent.totaltime;
                _tempDestNodes = new List<DestNodes>();
                _tempDestNodes = _NodeDetails.Where(a => a.Node == currentEntryNode).Select(t => t.ConnectingNodes).First();
                foreach (DestNodes dn in _tempDestNodes)
                {
                    if (dn.DestNode == FinalDestNode)
                    {
                        AddUnVisitedNodes(dn.DestNode, dn.travelTime, previousCoveredNodes, previousTravelTimes,true);
                    }
                    else
                    {
                        AddUnVisitedNodes(dn.DestNode, dn.travelTime, previousCoveredNodes,previousTravelTimes,false);
                    }
                }
                _processingNodes.Where(a => a.Node == currentEntryNode).Where(t => t.enroute == previousCoveredNodes).First().visited = true;
                
            }

            if (_processingNodes.Where(a => a.ReachedDestination == true).OrderBy(t=>t.totaltime).Count() > 0)
            {
                // get the shortest travel time if there were one or more routes for destination
                ProcessingRoutes psRoute= _processingNodes.Where(a => a.ReachedDestination == true).OrderBy(t => t.totaltime).First();
                return psRoute.enroute + ": " + psRoute.totaltime.ToString();
            }
            else
            {
                return "Destination Not found for given input";
            }

        }
        private void AddUnVisitedNodes(string Node,int ttime, string parent, int previousNodeTimes,bool reachedDest)
        {
            if (reachedDest == true)
            {
                _processingNodes.Add(new ProcessingRoutes()
                {
                    Node = Node,
                    visited = true,
                    enroute = parent + Node+" ",
                    totaltime = previousNodeTimes + ttime,
                    ReachedDestination = true
                });
            }
            else
            {
                if (_processingNodes.Where(a => a.Node == Node).Where(t => t.enroute == parent+Node+" ").Count() > 0)
                {
                    _processingNodes.Where(a => a.Node == Node).Where(t => t.enroute == parent + Node + " ").First().visited = true;
                }
                else
                {
                    if (Array.IndexOf(parent.Split(whiteSpaceDelimiter), Node) < 0)
                    {
                        _processingNodes.Add(new ProcessingRoutes()
                        {
                            Node = Node,
                            visited = false,
                            enroute = parent + Node + " ",
                            totaltime = previousNodeTimes + ttime,
                            ReachedDestination = false,
                        });
                    }
                }
            }
        }
        #endregion

        private string GetDestinationGate(string flightID)
        {
            if (_Departures.Where(a => a.flightId == flightID).Count() > 0)
            {
                return _Departures.Where(a => a.flightId == flightID).Select(s => s.flightGate).First();
            }
            else
            {
                return "";
            }
        }
        
        /* Method for adding departure Section details */
        private void AddDepartures(string flightid, string flightgate, string destination, TimeSpan flighttime)
        {
            _Departures.Add(new DepartureDetail()
            {
                DepartureTime=flighttime,
                DestinationCode=destination,
                flightGate=flightgate,
                flightId=flightid
            });
        }
        /* Method for adding Bags Section details */
        private void AddBagsDetails(string bagnumber, string EntyGate, string DestFlightID)
        {
            _Bags.Add(new BagDetail()
            {
                bagNumber = bagnumber,
                EntryPointGate = EntyGate,
                DestflightId = DestFlightID,
                
            });
        }
        /* Method for adding Node details to process routes */
        private void AddNodeDetails(string node1, string node2, int traveltime)
        {
            if(_NodeDetails.Where(a => a.Node == node1).Count() > 0)
            {
                _NodeDetails.Where(a => a.Node == node1).Select( a=>a.ConnectingNodes).First().Add(new DestNodes()
                {
                    DestNode =node2,
                    travelTime = traveltime 
                });;
   
            }
            else
            {
                _tempDestNodes =new List<DestNodes>();
                _tempDestNodes.Add(new DestNodes()
                {
                     DestNode =node2,
                    travelTime = traveltime 
                });
                _NodeDetails.Add(new NodeDetail()
                {
                    Node = node1,
                    ConnectingNodes = _tempDestNodes
                });
            }
            if(_NodeDetails.Where(a => a.Node == node2).Count() >0)
            {
                _NodeDetails.Where(a => a.Node == node2).Select(a => a.ConnectingNodes).First().Add(new DestNodes()
                {
                    DestNode = node1,
                    travelTime = traveltime
                }); ;
            }
            else
            {
                _tempDestNodes = new List<DestNodes>();
                _tempDestNodes.Add(new DestNodes()
                {
                    DestNode = node1,
                    travelTime = traveltime
                });
                _NodeDetails.Add(new NodeDetail()
                {
                    Node = node2,
                    ConnectingNodes = _tempDestNodes
                });
            }
        }
    }
}
