﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaggageRouteFinder
{
    public interface IRouting
    {
        
        string[] GenerateRoute();
        bool validateInputDataFormat(string[] inputStr);
    }
}
