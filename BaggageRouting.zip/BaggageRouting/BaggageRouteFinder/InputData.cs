﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaggageRouteFinder
{
    #region "Input Sections"
    
    class DepartureDetail
    {
        public string flightId { get; set; }
        public string flightGate { get; set; }
        public string DestinationCode { get; set; }
        public TimeSpan DepartureTime { get; set; }
    }
    class BagDetail
    {
        public string bagNumber { get; set; }
        public string EntryPointGate { get; set; }
        public string DestflightId { get; set; }
    }
    class ProcessingRoutes
    {
        public string Node { get; set; }
        public bool visited { get; set; }
        public string enroute { get; set; }
        public int totaltime { get; set; }
        public bool ReachedDestination { get; set; }
    }
   
    class DestNodes
    {
        public Int32 travelTime { get; set; }
        public string DestNode { get; set; }
    }
    class NodeDetail
    {
        public string Node { get; set; }
        public List<DestNodes> ConnectingNodes { get; set; }
    }
    #endregion

    #region "Output Class"
    class OptimalRoute
    {
        public string bagNumber { get; set; }
        public string RoutePoints { get; set; }
        public Int32 TotalTime { get; set; }
    }
    #endregion

}
