BaggageRoutingInterface  - GUI Interface(windows form application) project for collecting inputs and retriving outputs - startup project
BaggageRouteFinder - Class library for retrieving the optimized routes
