﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BaggageRouteFinder;


namespace BaggageRoutingInterface
{
    public partial class BaggageRoutingForm : Form
    {
        private readonly IRouting routingFinder;
        public BaggageRoutingForm()
        {
            InitializeComponent();
            routingFinder = new RouteFinder();
             
        }
        private void btnRouteGenerator_Click(object sender, EventArgs e)
        {
            
            bool validationpassed= routingFinder.validateInputDataFormat(txtInput.Lines);
            if (!validationpassed)
                MessageBox.Show("Incorrect format");

            txtOutput.Lines = routingFinder.GenerateRoute();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
